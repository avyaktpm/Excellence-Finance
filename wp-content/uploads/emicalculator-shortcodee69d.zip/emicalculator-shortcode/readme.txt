=== Responsive EMI Calculator Widget Shortcode ===
Contributors: http://emicalculator.net/
Tags: emi, calculator, EMI, shortcode, widget, responsive
Version: 2.0

Use responsive EMI calculator widget as shortcode in post content or widget area without editing your theme files



== Description ==
USAGE:
Use [emicalc] shortcode in your post content to show the responsive EMI calculator widget without editing your theme files

EXAMPLE:
[emicalc format="responsive"][/emicalc]



== Installation ==
1. Upload 'emicalculator-shortcode' folder to the '/wp-content/plugins/' directory

OR

Upload 'emicalculator-shortcode.zip' file through the 'Plugins -> Add New' menu in WordPress

2. Activate the plugin through the 'Plugins' menu in WordPress

3. Use the shortcode [emicalc format="responsive"][/emicalc]