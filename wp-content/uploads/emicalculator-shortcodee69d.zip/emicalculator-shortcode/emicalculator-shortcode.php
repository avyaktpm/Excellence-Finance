<?php
/*
Plugin Name: Responsive EMI Calculator Widget Shortcode
Description: Use Responsive EMI Calculator Widget as shortcode in post content
Plugin URI:  http://emicalculator.net/
Version:     2.0
*/

/*

USAGE:
Use [emicalc] shortcode in your post content or widget area to show the responsive EMI calculator widget.

EXAMPLE:
[emicalc format="responsive"][/emicalc]

*/
function emicalc_shortcode($atts, $content = null) {
	wp_register_script('ecww-loader', 'http://emicalculator.net/widget/2.0/js/emicalc-loader.min.js');
	wp_enqueue_script('ecww-loader');
	
	return '<div id="ecww-widgetwrapper" style="min-width:250px;width:100%;"><div id="ecww-widget" style="position:relative;padding-top:0;padding-bottom:280px;height:0;overflow:hidden;"></div><div id="ecww-more" style="background:#333;font:normal 13px/1 Helvetica, Arial, Verdana, Sans-serif;padding:10px 0;color:#FFF;text-align:center;width:100%;clear:both;margin:0;clear:both;float:left;"><a style="background:#333;color:#FFF;text-decoration:none;border-bottom:1px dotted #ccc;" href="http://emicalculator.net/" title="Loan EMI Calculator" rel="nofollow" target="_blank">emicalculator.net</a></div></div>';
}
@add_shortcode('emicalc','emicalc_shortcode');
?>